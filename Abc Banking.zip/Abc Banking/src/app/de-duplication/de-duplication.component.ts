import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-de-duplication',
  templateUrl: './de-duplication.component.html',
  styleUrls: ['./de-duplication.component.css']
})
export class DeDuplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
