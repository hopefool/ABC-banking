import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  addCustomerForm :FormGroup;
  constructor(private fb:FormBuilder,
    private customerService : CustomerServiceService,
    private router:Router) { }

  ngOnInit() {
    this.addCustomerForm = this.fb.group({
    customername: ['',[Validators.required]],
    dob: ['',[Validators.required]],
    address_line1: ['',[Validators.required]],
    address_line2: ['',[Validators.required]],
    city: ['',[Validators.required]],
    pincode: ['',[Validators.required]],
    email: [''],
    pan_number: [''],
    contact_number: ['',[Validators.required]],
    occupation: ['',[Validators.required]],
    income: [''],
    user_id: ['',[Validators.required]],
    password: ['',[Validators.required]],
    repassword: ['',[Validators.required]],
    });

  }
}
