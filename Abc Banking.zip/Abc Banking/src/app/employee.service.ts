import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { stringify } from 'querystring';

const httpOptions ={

  headers: new HttpHeaders({

    'Content-type':'application/json'
  })

};

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private headers = new HttpHeaders({'Content-Type':'application/json'});




  constructor(private http:HttpClient) { }
  public getAllEmployees(){

    return this.http.get('http://localhost:8010/employee/list');

  }

  
}
