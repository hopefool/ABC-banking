import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {

  employeeList:Employee[]=[];

  constructor(private employeeService: EmployeeService, private r: Router) { }

  getService() {
    this.employeeService.getAllEmployees().subscribe((data: Employee[])  =>this.employeeList = data);   
    // this.employeeService.getAllEmployees().subscribe((data: any[]) => console.log(data));   
  }

  ngOnInit() {
    this.getService();
  }
}
