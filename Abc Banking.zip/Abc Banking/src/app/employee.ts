export class Employee{

    public employeeId:number;
    public username :string;
    public password:string;
    public designation:string;

}