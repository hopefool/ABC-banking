import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ListEmployeeComponent } from './list-employee/list-employee.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { SearchCustomerComponent } from './search-customer/search-customer.component';
import { DeDuplicationComponent } from './de-duplication/de-duplication.component';


const routes: Routes = [

{path:"login", component:LoginComponent},
{path:"employee",component:AddEmployeeComponent},
{path:"list" ,component:ListEmployeeComponent},
{path:"menu",component:MainMenuComponent},
{path:"menu/search",component:SearchCustomerComponent},
{path:"menu/addemployee",component:AddEmployeeComponent},
{path:"menu/dedup",component:DeDuplicationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
